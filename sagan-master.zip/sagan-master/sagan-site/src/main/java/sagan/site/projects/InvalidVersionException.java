package sagan.site.projects;

public class InvalidVersionException extends RuntimeException {

	public InvalidVersionException(String message) {
		super(message);
	}
	
}
