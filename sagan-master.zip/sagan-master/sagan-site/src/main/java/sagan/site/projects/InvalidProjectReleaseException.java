package sagan.site.projects;

public class InvalidProjectReleaseException extends RuntimeException {

	public InvalidProjectReleaseException(String message) {
		super(message);
	}

}
