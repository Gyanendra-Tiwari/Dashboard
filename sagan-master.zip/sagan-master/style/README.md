This directory contains configuration files for source code formatting. Everything is based on Eclipse's formatting and import order rules. IDEA users can work directly with these files using the [Eclipse code formatter plugin for IDEA][1]

[1]: https://code.google.com/p/eclipse-code-formatter-intellij-plugin/wiki/HowTo
